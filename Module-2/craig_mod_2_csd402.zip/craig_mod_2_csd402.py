# Rock-Paper-Scissors
# Christopher Craig | Module 2 | CSD-402

import random


def get_choice_name(number):
    """Returns the name of the choice based on the number (1, 2, or 3)."""
    if number == 1:
        return "Rock"
    elif number == 2:
        return "Paper"
    else:
        return "Scissors"


def determine_winner(user_choice, computer_choice):
    """Compares user and computer choices and returns the result."""
    if user_choice == computer_choice:
        return "It's a tie!"
    elif (user_choice == 1 and computer_choice == 3) or \
         (user_choice == 2 and computer_choice == 1) or \
         (user_choice == 3 and computer_choice == 2):
        return "You win!"
    else:
        return "Computer wins!"


def play_game():
    """Main game function — handles input, logic, and output."""

    print("=" * 40)
    print("       ROCK - PAPER - SCISSORS")
    print("=" * 40)
    print("  1 = Rock")
    print("  2 = Paper")
    print("  3 = Scissors")
    print("=" * 40)

    # Get user input
    try:
        user_choice = int(input("\nEnter your choice (1, 2, or 3): "))
        if user_choice not in [1, 2, 3]:
            print("Invalid input. Please enter 1, 2, or 3.")
            return
    except ValueError:
        print("Invalid input. Please enter a number (1, 2, or 3).")
        return

    # Generate computer choice
    computer_choice = random.randint(1, 3)

    # Get names for display
    user_name = get_choice_name(user_choice)
    computer_name = get_choice_name(computer_choice)

    # Determine and display result
    result = determine_winner(user_choice, computer_choice)

    print("\n" + "=" * 40)
    print(f"  Your choice:      {user_name}")
    print(f"  Computer's choice: {computer_name}")
    print("-" * 40)
    print(f"  Result: {result}")
    print("=" * 40)


# --- Run the game ---
play_game()
